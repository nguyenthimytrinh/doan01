<meta charset='utf-8'>
<?php
$a=5;
var_dump($a);
?>