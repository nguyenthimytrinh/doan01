<meta charset='utf-8'>
<?php
$a=3;
$b=4;
echo "phần nguyên của $a chia $b là".$c=($a/$b)."<br/>";
echo "phần dư của $a chia $b là".$e=($a%$b);

?>