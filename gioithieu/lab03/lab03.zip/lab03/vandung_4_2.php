<meta charset='utf-8'>
<?php
$tong=0;
$i=0;
while($tong<=1000)
	{
		$i++;
		$tong+=$i;
		
	}
	echo $i.'là n nhỏ nhất để cho 1 + 2 + …+ n >1000';


?>