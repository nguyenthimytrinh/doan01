<meta charset='utf-8'>
<?php
$tong=0;
for($i=2;$i<=100;$i++)
	{
		if($i%2==0)
			$tong+=$i;
	}
	print "tổng số chẵn từ 2 đến 100 là:".$tong;
?>