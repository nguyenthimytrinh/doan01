 <table width="100%" border="0" bgcolor="#FFFFAA">
        <tr>
          <td><a href="index.php">Home</a></td>
          <td><a href="index.php?mod=info&ac=gioithieu">Giới thiệu</a></td>
          <td><a href="index.php?mod=product&ac=spbc">Sách bán chạy</a></td>
          <td><a href="index.php?mod=product&ac=spmoi">Sách mới</a></td>
          <td>Tin tức</td>
          <td>Liên hệ</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><a href="admin/index.php">admin</a></td>
        </tr>
      </table>