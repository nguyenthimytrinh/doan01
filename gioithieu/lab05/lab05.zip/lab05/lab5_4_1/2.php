<meta charset='utf-8'>
<?php
$name="";
if(isset($_GET["id"]))
	$name=$_GET["id"];
echo $name;
?>