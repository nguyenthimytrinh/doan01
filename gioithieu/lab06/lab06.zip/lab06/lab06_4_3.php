<?php
$content = file_get_contents("http://thethao.vnexpress.net/");
echo $content;
?>